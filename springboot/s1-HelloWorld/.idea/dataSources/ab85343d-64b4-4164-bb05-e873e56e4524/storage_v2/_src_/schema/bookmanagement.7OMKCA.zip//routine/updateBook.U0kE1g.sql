create
    definer = root@localhost procedure updateBook(IN bookNumber int, IN bookExisting int)
begin
    update bookinf
    set
        bExisting=bookExisting
    where bNumber = bookNumber;
end;

