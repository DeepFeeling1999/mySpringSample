create
    definer = root@localhost procedure addBook(IN bookNumber int, IN bookName char(11), IN bookTotal int,
                                               IN bookExisting int)
begin
    insert
    into bookinf( bNumber, bName, bTotal, bExisting )
        value
        (bookNumber, bookName, bookTotal, bookExisting);

end;

