create
    definer = root@localhost procedure showBook()
begin
    select *
    from bookinf;
end;

