create
    definer = root@localhost procedure borrowBook(IN bookName char(11), IN readerNumber int)
begin
    if ((select bExisting from bookinf where BookInf.bName = bookName) > 0) then
        #插入借阅信息
        insert
        into borrowsystem( rNumber, bNumber ) VALUE
            (readerNumber, (select bNumber from bookinf where bName = bookName));

        #更新现存数目
        update bookinf
        set
            bExisting=bExisting - 1
        where bName = bookName;
    else
        select 'borrow error!';
    end if;

end;

