create
    definer = root@localhost procedure seekBook(IN bookNumber int)
begin
    select *
    from bookinf
    where bNumber = bookNumber;
end;

