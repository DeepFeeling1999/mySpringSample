create
    definer = root@localhost procedure deleteBook(IN bookName char(11))
begin

        delete
        from bookinf
        where bName = bookName;
end;

